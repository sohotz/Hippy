/**
 * 工程中的常用变量
 *
 * @since 2021/12/29
 */
export declare class CommonConst {
    static readonly HARMONY_OS: string;
    static readonly BUILD_FILE_NAME: string;
    static readonly PACKAGE_JSON: string;
    static readonly OH_PACKAGE_JSON5: string;
    static readonly OH_MODULES: string;
    static readonly LOCAL_PROPERTIES: string;
    static readonly PROFILE_JSON5: string;
    static readonly MODULE_JSON: string;
    static readonly APP_SCHEMA_JSON: string;
    static readonly FORM_SCHEMA_JSON: string;
    static readonly PAGE_SCHEMA_JSON: string;
    static readonly MODULE_JSON5: string;
    static readonly CONFIG_JSON: string;
    static readonly APP_CONFIG: string;
    static readonly ETS_WEBPACK_FILE: string;
    static readonly ACE_RICH_WEBPACK_FILE: string;
    static readonly ACE_LITE_WEBPACK_FILE: string;
    static readonly DEBUGGABLE: string;
    static readonly HOT_RELOAD: string;
    static readonly PREVIEW_MODE: string;
    static readonly UNIT_TEST_MODE: string;
    static readonly OHOS_TEST_COVERAGE: string;
    static readonly RPCID_JSON: string;
    static readonly RPCID_SC: string;
    static readonly SYSCAP_JSON: string;
    static readonly RES_CONFIG_FILE: string;
    static readonly WARM_UP_SCRIPT: string;
    static readonly ADDED_SYSCAPS: string;
    static readonly REMOVED_SYSCAPS: string;
    static readonly DEVICETYPE: string;
    static readonly DEVICETYPES: string;
    static readonly COMPILE_CONFIG: string;
    static readonly PATCH_CONFIG: string;
    static readonly FRAMEWORK_CONFIGURATION: string;
    static readonly SINGLE_FRAMEWORK: string;
    static readonly DOUBLE_FRAMEWORK: string;
    static readonly OPEN_HARMONY: string;
    static readonly BASE_PROFILE: string;
    static readonly ASSEMBLE_APP: string;
    static readonly ASSEMBLE_HAP: string;
    static readonly DEFAULT_PACKAGE_NAME: string;
    static readonly DEFAULT_MODULE_NAME: string;
    static readonly DEFAULT_DESIGN_WIDTH: number;
    static readonly OBFUSCATION_TXT: string;
    static readonly OBFUSCATION_FILES_HASH: string;
    static readonly OBFUSCATION_ENABLE: string;
    static readonly BUILD_MODE: string;
}
/**
 * Node环境中的常量
 */
export declare class CommonNodeConst {
    static readonly NODE_EXE: string;
    static readonly NODE: string;
    static readonly NODE_MODULES: string;
}
/**
 * module默认包含的target
 */
export declare class DefaultTargetConst {
    static readonly DEFAULT_TARGET: string;
    static readonly OHOS_TEST_TARGET: string;
}
export declare class BuildProfileSchemaFileConst {
    static readonly HAP_MODULE_BUILD_PROFILE_SCHEMA_PATH: string;
    static readonly HAR_MODULE_BUILD_PROFILE_SCHEMA_PATH: string;
    static readonly PROJECT_BUILD_PROFILE_SCHEMA_PATH: string;
    static readonly ARKUI_X_CONFIG_SCHEMA_PATH: string;
}
export declare class ArkPackConst {
    static readonly COMPILE_TOOL: string;
}
export declare enum PageType {
    PAGE = "page",
    CARD = "card"
}
export declare enum BundleType {
    APP = "app",
    ATOMIC_SERVICE = "atomicService"
}
export declare class CustomTypesConst {
    static readonly CUSTOM_TYPES_SUFFIX: string[];
    static readonly CUSTOM_TYPES_INDEX: string[];
}
