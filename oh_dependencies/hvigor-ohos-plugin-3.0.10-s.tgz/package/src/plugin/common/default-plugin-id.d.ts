/**
 * 默认的Ohos plugin中对应的三种Module的plugin id
 *
 * @since 2022/5/5
 */
export declare class DefaultPluginId {
    static readonly OHOS_APP_PLUGIN = "com.ohos.app";
    static readonly OHOS_HAP_PLUGIN = "com.ohos.hap";
    static readonly OHOS_HAR_PLUGIN = "com.ohos.har";
    static readonly OHOS_HSP_PLUGIN = "com.ohos.hsp";
}
