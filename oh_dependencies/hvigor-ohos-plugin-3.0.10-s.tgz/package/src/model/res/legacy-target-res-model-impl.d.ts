import { ConfigJson } from '../../options/configure/config-json-options.js';
import { CoreResModelImpl } from './core-res-model-impl.js';
import ConfigOptObj = ConfigJson.ConfigOptObj;
/**
 * Fa Module 的不同target对应的资源集合
 *
 * @since 2022/2/23
 */
export declare class LegacyModuleTargetResImpl extends CoreResModelImpl {
    protected _configJsonOpt: ConfigOptObj | undefined;
    private _log;
    constructor(sourceSetRoot: string);
    getConfigJsonOpt(): ConfigOptObj;
    hasLiteDevice(): boolean | undefined;
    supportLiteDeviceModule(): boolean;
    getShellApplicationPackage(): string;
}
