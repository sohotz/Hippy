import { BaseCommandBuilder } from './base-command-builder.js';
export declare class IdlCommandBuilder extends BaseCommandBuilder {
    constructor(executor: string);
    generateJava(): IdlCommandBuilder;
    addOutputDir(output: string): IdlCommandBuilder;
    compileIdlFile(file: string): IdlCommandBuilder;
}
