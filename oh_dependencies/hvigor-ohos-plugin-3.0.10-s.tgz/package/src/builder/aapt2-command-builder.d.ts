import { BaseCommandBuilder } from './base-command-builder.js';
export declare class Aapt2CommandBuilder extends BaseCommandBuilder {
    constructor(executor: string);
    compile(): Aapt2CommandBuilder;
    link(): Aapt2CommandBuilder;
    showDetail(): Aapt2CommandBuilder;
    addDirectory(dir: string): Aapt2CommandBuilder;
    addOutputPath(outputPath: string): this;
    addApkPath(apkPath: string): Aapt2CommandBuilder;
    addRFilePath(rFilePath: string): Aapt2CommandBuilder;
    addManifestPath(manifest: string): Aapt2CommandBuilder;
    addPackageId(packageId: string): Aapt2CommandBuilder;
    addIntermediates(intermediates: string): Aapt2CommandBuilder;
}
