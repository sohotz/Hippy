import { BaseCommandBuilder } from './base-command-builder.js';
export declare class JarCommandBuilder extends BaseCommandBuilder {
    constructor();
    addOptions(options: string): JarCommandBuilder;
    addJarFile(jarFile: string): JarCommandBuilder;
    addFiles(files: string): JarCommandBuilder;
    addSpecDir(dir: string): JarCommandBuilder;
}
