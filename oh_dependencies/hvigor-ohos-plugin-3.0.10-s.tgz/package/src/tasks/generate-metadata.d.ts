import { AbstractGenerateMetadata } from './abstract/abstract-generate-metadata.js';
import { TargetTaskService } from './service/target-task-service.js';
import { FileSet } from '@ohos/hvigor';
import { ModuleBuildProfile } from '../options/build/module-build-profile.js';
import { ModuleTargetData } from './data/hap-task-target-data.js';
/**
 * Generate OutputMetadata Task
 */
export declare class GenerateMetadata extends AbstractGenerateMetadata {
    private _hspDepsTarget;
    constructor(targetService: TargetTaskService);
    declareInputFiles(): FileSet;
    protected initTaskDependsForOtherModule(): void;
    protected getDistroFilterObj(relatedEntryTargetData: ModuleTargetData): ModuleBuildProfile.DistroFilterBuildOpt | undefined;
}
