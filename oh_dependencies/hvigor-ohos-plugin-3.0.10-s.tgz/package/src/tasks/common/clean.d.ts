import { DefaultTask, HvigorNode } from '@ohos/hvigor';
import { TaskService } from '../service/task-service.js';
/**
 * module级别的clean
 *
 * @since 2022/1/10
 */
export declare class Clean extends DefaultTask {
    private readonly _taskService;
    private _logger;
    constructor(node: HvigorNode, taskService: TaskService);
    registryAction: () => Function;
    clean: () => void;
    rmdirSync: (dirPath: string, hasError: boolean) => boolean;
}
