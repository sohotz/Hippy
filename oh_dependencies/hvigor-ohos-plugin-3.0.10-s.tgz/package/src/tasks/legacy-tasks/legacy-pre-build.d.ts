import { FileSet } from '@ohos/hvigor';
import { JsonProfile } from '../../model/json-profile.js';
import { AbstractPreBuild } from '../abstract/abstract-pre-build.js';
import { TargetTaskService } from '../service/target-task-service.js';
/**
 * Fa module preBuild Task
 *
 * @since 2022/9/8
 */
export declare class LegacyPreBuild extends AbstractPreBuild {
    private readonly targetJsonPath;
    private readonly targetConfigOptObj;
    private logger;
    declareInputFiles(): FileSet;
    constructor(taskService: TargetTaskService);
    protected doValidateForDiffApiType(): void;
    protected getJsonProfileByModel(): JsonProfile;
    private validateJsType;
    private validateAbilities;
    private validateForm;
}
