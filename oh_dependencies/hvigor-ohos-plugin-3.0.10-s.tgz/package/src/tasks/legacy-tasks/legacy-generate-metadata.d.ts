import { AbstractGenerateMetadata } from '../abstract/abstract-generate-metadata.js';
import { TargetTaskService } from '../service/target-task-service.js';
import { ModuleBuildProfile } from '../../options/build/module-build-profile.js';
import { FileSet } from '@ohos/hvigor';
import { ModuleTargetData } from '../data/hap-task-target-data.js';
/**
 * Legacy Generate OutputMetadata Task
 */
export declare class LegacyGenerateMetadata extends AbstractGenerateMetadata {
    private readonly configJsonPath;
    constructor(targetService: TargetTaskService);
    declareInputFiles(): FileSet;
    protected getDistroFilterObj(relatedEntryTargetData: ModuleTargetData): ModuleBuildProfile.DistroFilterBuildOpt | undefined;
}
