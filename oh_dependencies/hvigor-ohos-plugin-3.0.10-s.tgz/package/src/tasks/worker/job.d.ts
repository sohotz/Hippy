import { ProjectConfig } from '@ohos/hvigor-arkts-compose';
export declare const run: (config: ProjectConfig) => Promise<void>;
export declare const runArkLint: (config: {
    config: ProjectConfig;
    entry: Record<string, unknown>;
}) => Promise<void>;
