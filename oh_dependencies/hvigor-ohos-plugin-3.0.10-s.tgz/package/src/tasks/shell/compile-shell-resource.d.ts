import { FileSet } from '@ohos/hvigor';
import { RestoolCommandBuilder } from '../../builder/restool-command-builder.js';
import { AbstractCompileResource } from '../abstract/abstract-compile-resource.js';
import { TargetTaskService } from '../service/target-task-service.js';
/**
 * use restool change res to shell
 *
 * @since 2022/4/14
 */
export declare class CompileShellResource extends AbstractCompileResource {
    private _log;
    constructor(taskService: TargetTaskService);
    declareInputFiles(): FileSet;
    declareOutputFiles(): FileSet;
    initTaskDepends(): void;
    taskShouldDo(): boolean;
    protected beforeTask(): void;
    protected getResToolFile(): string;
    protected doTaskAction(): Promise<void>;
    protected getRestoolCommandBuilder(): RestoolCommandBuilder;
    private initCommandTargetResource;
    /**
     * get current modules in target
     *
     * @returns {string[]}
     * @protected
     */
    protected getRestoolModules(): string[];
}
