import { FileSet, TaskDetails, TaskInputValue } from '@ohos/hvigor';
import { SourceSetModel } from '../../model/source-set/source-set-model.js';
import { ModuleBuildProfile } from '../../options/build/module-build-profile.js';
import { ModuleTargetData } from '../data/hap-task-target-data.js';
import { TargetTaskService } from '../service/target-task-service.js';
import { OhosHapTask } from '../task/ohos-hap-task.js';
import DistroFilterBuildOpt = ModuleBuildProfile.DistroFilterBuildOpt;
/**
 * 构建根据feature与entry关联关系生成对应output_metadata.json
 * path:{buildRoot}/{moduleName}/build/{productName}/intermediates/hap_metadata/{targetName}/output_metadata.json
 */
export declare abstract class AbstractGenerateMetadata extends OhosHapTask {
    protected readonly sourceSetModel: SourceSetModel;
    protected constructor(targetService: TargetTaskService, taskDetails: TaskDetails);
    protected doTaskAction(): void;
    declareInputs(): Map<string, TaskInputValue>;
    declareOutputFiles(): FileSet;
    initTaskDepends(): void;
    /**
     * 根据target生成output_metadata.json
     *
     * @param targetData featureTargetData
     * @private
     */
    private generateTargetMetadata;
    private generateEntryMetadata;
    private generateFeatureMetadata;
    private generateHspMetadata;
    private isSigned;
    protected abstract getDistroFilterObj(relatedEntryTargetData: ModuleTargetData): DistroFilterBuildOpt | undefined;
    protected getRelatedEntryJsonList(jsonFile: string): string[];
}
