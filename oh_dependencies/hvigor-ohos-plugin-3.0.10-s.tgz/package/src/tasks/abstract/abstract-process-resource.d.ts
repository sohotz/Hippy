import { FileSet, TaskDetails, TaskInputValue } from '@ohos/hvigor';
import { RestoolCommandBuilder } from '../../builder/restool-command-builder.js';
import { RestoolConfigBuilder } from '../../builder/restool-file-config-builder.js';
import { TargetTaskService } from '../service/target-task-service.js';
import { OhosHapTask } from '../task/ohos-hap-task.js';
/**
 * 编译前的资源处理和生成resConfig.json的公共抽象类
 *
 * @since 2022/9/8
 */
export declare abstract class AbstractProcessResource extends OhosHapTask {
    restoolConfigBuilder: RestoolConfigBuilder;
    restoolCommandBuilder: RestoolCommandBuilder;
    outputDir: string | undefined;
    protected resConfigFilePath: string | undefined;
    protected entryModuleName: string | undefined;
    protected processedJson: string;
    protected constructor(taskService: TargetTaskService, taskDetails: TaskDetails);
    initTaskDepends(): void;
    protected doTaskAction(): void;
    abstract initCommandBuilder(): void;
    getCompileResourceInputFiles(): FileSet;
    getCompileResourceOutputFiles(): FileSet;
    declareInputs(): Map<string, TaskInputValue>;
    declareOutputFiles(): FileSet;
    /**
     * get common restool config builder
     *
     * @returns {RestoolBuilderInterface} resTool命令构造器
     */
    private getRestoolConfigBuilder;
    private initConfigTargetResource;
    /**
     *  相对路径转换为资源绝对路径
     *
     * @param {string}  resourcesDirs 资源路径
     * @param {Function} returnAfterProcessResourcePath 资源路径回调函数
     */
    convertResourceAbsolutePath(resourcesDirs: string[], returnAfterProcessResourcePath?: Function): void;
    /**
     * get common restool command builder
     *
     * @returns {RestoolBuilderInterface} resTool编译、链接命令构造器
     * @protected
     */
    protected getRestoolCommandBuilder(): RestoolCommandBuilder;
    protected initCommandTargetResource(): RestoolCommandBuilder;
    /**
     * is enabled icon check.
     *
     * @return {boolean} true/false
     */
    isEnabledIconCheck(): boolean;
    /**
     * ohosTest编译资源时同时编译src/main下的resources默认资源
     * 在Ability.test.ets中引用main下的ets文件时，可能会使用main下的resources资源
     * 多个moduleResource编译时，先添加的inputDir比后者优先级高
     * @param {RestoolConfigBuilder} restoolConfigBuilder resConfig.json资源编译入参对象
     */
    addOhosTestExtraCompilationResources(restoolConfigBuilder: RestoolConfigBuilder): void;
}
