import { FileSet, TaskInputValue } from '@ohos/hvigor';
import { Dependency } from '../project/dependency/core/dependency-interface.js';
import { TargetTaskService } from './service/target-task-service.js';
import { AbstractGenerateLoaderJson } from './abstract-generate-loader-json.js';
/**
 * 生成loader需要的json文件
 *
 * @since 2022/3/3
 */
export declare class GenerateLoaderJson extends AbstractGenerateLoaderJson {
    private readonly aceLoaderJson;
    private readonly nodeModulesPath;
    private readonly harNameOhmMap;
    private readonly apPath?;
    private readonly tempApPath;
    private readonly tempApDir;
    private readonly anBuildOutPutPath;
    private readonly fallbackAnBuild;
    private readonly typeExts;
    declareInputs(): Map<string, TaskInputValue>;
    declareInputFiles(): FileSet;
    declareOutputFiles(): FileSet;
    initTaskDepends(): void;
    constructor(taskService: TargetTaskService);
    protected doTaskAction(): void;
    /**
     * 检查当前Sdk版本是否支持Aot
     * @private
     */
    private checkAotCompatibleSdkVersion;
    private handleAotFields;
    private warnAnBuildMode;
    /**
     * 生成harNameOhmMap对象
     * @private
     */
    private getHarNameOhmMap;
    /**
     * 共享hsp包配置loader.json的harNameOhmMap时，获取package.json的main字段，如main字段为空则试图获取types字段
     * @param dependency
     */
    getHspDependencyPackageMainName(dependency: Dependency): string;
    /**
     * 共享hsp包配置loader.json的harNameOhmMap时，获取module.json5的name字段
     * @param dependency
     */
    getHspDependencyModuleName(dependency: Dependency): string;
    /**
     * 使用策略模式，
     *
     * @param {AotConfigsParams} params
     * @returns {Record<string, string>}
     * @private
     */
    private getAotStrategy;
    /**
     * 当ap路径存在时返回的loader.json片段
     * @param {AotConfigsParams} conf
     * @private
     */
    private withApPath;
    /**
     * 当ap路径不存在时返回的loader.json片段
     * @param {AotConfigsParams} conf
     * @private
     */
    private withoutApPath;
    /**
     * 当不使能aot编译时，返回空片段
     * @returns {{}}
     * @private
     */
    private withEmpty;
    /**
     * api9上配置了apPath但没有配置aotCompileMode，需要报错
     * @private
     */
    private mismatchAotCompileMode;
    /**
     * api9上配置了partial模式时没有配置apPath，需要报错
     * @private
     */
    private partialEmptyPath;
    /**
     * 配置了partial模式时apPath路径不存在，需要报错
     * @private
     */
    private invalidPath;
    /**
     * 路径非以.ap后缀结尾，需要报错
     * @private
     */
    private invalidSuffix;
}
