import { FileSet } from '@ohos/hvigor';
import { AbstractCompileResource } from './abstract/abstract-compile-resource.js';
import { ModuleTargetData } from './data/hap-task-target-data.js';
import { TargetTaskService } from './service/target-task-service.js';
import { ProcessResource } from './process-resource.js';
/**
 * 编译资源
 *
 * @since 2022/1/10
 */
export declare class CompileResource extends AbstractCompileResource {
    private _log;
    declareInputFiles(): FileSet;
    declareExecutionCommand(): string;
    constructor(targetTaskService: TargetTaskService, processResource: ProcessResource);
    initTaskDepends(): void;
    protected doTaskAction(): Promise<void>;
    invokeRestool(targetData: ModuleTargetData): Promise<void>;
}
