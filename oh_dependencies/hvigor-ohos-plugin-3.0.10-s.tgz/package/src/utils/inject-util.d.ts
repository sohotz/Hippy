/**
 * 通过hvigor命令行-p拿到一些固定的值
 *
 * @since 2022/5/17
 */
export declare class InjectUtil {
    /**
     * 判断是否是hot reload模式
     * 默认(不配置)是false
     *
     * @returns {boolean}
     */
    static isHotReload(): boolean;
    /**
     * 判断是否在preview的流程中调用task
     *
     * @returns {boolean}
     */
    static isPreviewProcess(): boolean;
    /**
     * 判断是否在unitTest的流程中调用task
     *
     * @returns {boolean}
     */
    static isUnitTestProcess(): boolean;
    /**
     * 判断是否ohosTest coverage模式打包
     *
     * @returns {boolean}
     */
    static isOhosTestCoverage(): boolean;
}
