/**
 * 处理文件的工具类
 *
 * @since 2021/12/29
 */
export declare class FileUtil {
    private static _log;
    static isDirectory(...pathSegments: string[]): boolean;
    static checkDirWithoutDelete(...pathSegments: string[]): void;
    static checkFile(...pathSegments: string[]): void;
    static makeFile(filePath: string, data?: string): void;
    static deleteFile(filePath: string): void;
    static readFile(filePath: string): string | undefined;
    /**
     * 校验路径长度
     *
     * @param path 待校验的路径
     */
    static checkPathLength(path: string): void;
    static hashEntry(dir: string, test?: RegExp): string;
    private static readDir;
    /**
     * 将路径转换为绝对路径
     *
     * @param {string} dir 文件或目录路径
     * @param {string} currentDir 当前路径，参考路径
     * @return {string} 转换后的绝对路径
     */
    static convertToAbsolutePath(dir: string, currentDir: string): string;
    static isSubDir(parent: string, child: string): boolean | "";
    /**
     * 校验文件是否存在
     *
     * @param completePath 文件完整路径
     */
    static fileExists(completePath: string): boolean;
    static copySpecialFileToTempDir(_moduleDir: string, taskTmpDir: string): void;
    static checkSpecialFile(fileName: string): boolean;
}
