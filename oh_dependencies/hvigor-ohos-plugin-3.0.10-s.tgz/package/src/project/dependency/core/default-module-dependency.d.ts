import { Module } from '@ohos/hvigor';
import { PackageJson } from 'type-fest';
import { DefaultNpmDependency } from './default-npm-dependency.js';
import { DependencyEnum, DependencyType } from './dependency-interface.js';
/**
 * module依赖的工程内的本地har模块
 *
 * @since 2022/5/7
 */
export declare class DefaultModuleDependency extends DefaultNpmDependency {
    private readonly _moduleName;
    constructor(module: Module, dependencyName: string, pkgJsonPath: string, packJsonObj: PackageJson, dependencyType: DependencyType, dependencyEnum: DependencyEnum);
    getModuleName(): string;
}
