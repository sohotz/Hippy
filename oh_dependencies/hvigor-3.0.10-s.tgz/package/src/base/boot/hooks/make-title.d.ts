/**
 * Make process title
 *
 * @param {string} cmd process cmd
 * @param {string[]} argv yargs argv
 */
export declare function makeTitle(cmd: string, argv: string[]): string;
