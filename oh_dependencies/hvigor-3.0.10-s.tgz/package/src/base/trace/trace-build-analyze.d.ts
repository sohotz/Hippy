/**
 * 打点数据构建时间解析
 *
 * @since 2022/6/11
 */
declare class TraceBuildAnalyze {
    totalTime: number;
    moduleNum: number;
    isIncremental: boolean;
    hasIncremental: boolean;
    isParallel: boolean;
    aotCompileMode?: string;
    /**
     * 打点数据Task执行时间
     * 取多个模块相同任务执行时间的最大值
     * 时间单位是纳秒
     */
    taskTime: Map<string, number>;
    constructor();
}
export declare const traceBuildAnalyze: TraceBuildAnalyze;
export {};
