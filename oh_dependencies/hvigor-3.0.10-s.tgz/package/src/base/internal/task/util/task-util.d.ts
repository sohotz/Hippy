import { Task } from '../../../external/task/task.js';
/**
 * 根据Task的path返回对应Task
 *
 * @param {string} taskPath
 * @return {Task}
 */
export declare function findTaskByPath(taskPath: string): Task;
