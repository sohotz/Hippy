export declare const TASK_EXECUTE_STATUS: {
    BLOCKED: number;
    PENDING: number;
    RUNNING: number;
    END: number;
    CANCELLED: number;
    FAILED: number;
};
/**
 * 用于保存一些任务执行状态的信息
 *
 * @since 2022/9/1
 */
export declare class TaskExecuteStatus {
    private _state;
    private _submitWorkIdList;
    private _taskBeginTime;
    private _isUpToDate;
    unTrackStateReason: string | undefined;
    constructor();
    setState(state: number): void;
    getState(): number;
    addWorkId(workId: string): void;
    setWorkFinished(workId: string): void;
    allWorksHasFinished(): boolean;
    getTaskBeginTime(): [number, number] | undefined;
    setIsUpToDate(upToDate: boolean): void;
    isUpToDate(): boolean;
}
