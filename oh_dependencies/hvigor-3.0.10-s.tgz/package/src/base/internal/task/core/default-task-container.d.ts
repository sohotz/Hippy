import { Task } from '../../../external/task/task.js';
import { TaskContainer } from '../interface/task-container-interface.js';
import { TaskDirectedAcyclicGraph } from './task-directed-acyclic-graph.js';
/**
 * module的Task容器管理的默认实现
 *
 * @since 2022/4/24
 */
export declare class DefaultTaskContainer implements TaskContainer {
    private readonly _moduleName;
    private _tasks;
    private _taskGraph;
    private _log;
    constructor(moduleName: string, taskGraph: TaskDirectedAcyclicGraph);
    addTask(task: Task): void;
    deleteTask(taskName: string): boolean;
    findTask(taskName: string): Task | undefined;
    getAllTasks(): Task[];
    hasTask(taskName: string): boolean;
}
