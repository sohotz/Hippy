import { Task } from '../../../external/task/task.js';
/**
 * 一个包含Task队列的对象
 *
 * @since 2022/0813
 */
export declare class TaskQueue {
    private taskQueue;
    constructor(capacity?: number);
    push(task: Task): boolean;
    pop(): Task | undefined;
    peek(): Task | undefined;
    size(): number;
    toString(): string;
    isEmpty(): boolean;
    clear(): void;
}
