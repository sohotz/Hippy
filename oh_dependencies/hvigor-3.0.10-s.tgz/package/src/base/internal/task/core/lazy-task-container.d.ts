import { Task } from '../../../external/task/task.js';
import { TaskContainer } from '../interface/task-container-interface.js';
export declare class LazyTaskContainer implements TaskContainer {
    private readonly _moduleName;
    private _tasks;
    constructor(moduleName: string);
    addTask(task: Task): void;
    deleteTask(taskName: string): boolean;
    hasTask(taskName: string): boolean;
    getAllTasks(): Task[];
    findTask(taskName: string): Task | undefined;
}
