/**
 * 任务的Work执行相关的监听
 *
 * @type {{WORK_FINISHED: string, WORK_UP_TO_DATE: string, WORK_FAILED: string}}
 */
export declare const TASK_CENTER_WORK_EVENT_ID: {
    WORK_FINISHED: string;
    WORK_FAILED: string;
    WORK_UP_TO_DATE: string;
};
/**
 * 任务的执行相关的监听
 *
 * @type {{TASK_DISABLED: string, TASK_FAILED: string, TASK_UP_TO_DATE: string, TASK_FINISHED: string}}
 */
export declare const TASK_CENTER_TASK_EVENT_ID: {
    TASK_FINISHED: string;
    TASK_FAILED: string;
    TASK_UP_TO_DATE: string;
    TASK_DISABLED: string;
};
