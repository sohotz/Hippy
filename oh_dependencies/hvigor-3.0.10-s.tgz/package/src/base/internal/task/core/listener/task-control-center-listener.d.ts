import { CoreTaskImpl } from '../../../../external/task/core-task-impl.js';
import type { TaskControlCenter } from '../task-control-center.js';
/**
 * Task的不同类型监听的接口类
 *
 * @since 2022/9/1
 */
export interface TaskControlCenterListener {
    /**
     * 通过Emit触发事件后,监听需要执行的具体逻辑
     *
     * @param {CoreTaskImpl} task
     */
    executeListener(task: CoreTaskImpl, args?: any): void;
}
/**
 * Task不同类型监听的默认实现
 *
 * @since 2022/9/1
 */
declare abstract class DefaultTaskControlCenterListener implements TaskControlCenterListener {
    protected taskControlCenter: TaskControlCenter;
    protected constructor(taskControlCenter: TaskControlCenter);
    abstract executeListener(task: CoreTaskImpl): void;
}
/**
 * 任务的单个Work执行结束后触发的事件监听
 *
 * @since 2022/9/1
 */
export declare class WorkFinishedListener extends DefaultTaskControlCenterListener {
    constructor(taskControlCenter: TaskControlCenter);
    executeListener(task: CoreTaskImpl): void;
}
/**
 * 任务的单个Work执行失败后触发的事件监听
 *
 * @since 2022/9/1
 */
export declare class WorkFailedListener extends DefaultTaskControlCenterListener {
    constructor(taskControlCenter: TaskControlCenter);
    executeListener(task: CoreTaskImpl, args?: any): void;
}
/**
 * 整个任务执行结束后触发的事件监听
 *
 * @since 2022/9/1
 */
export declare class TaskFinishedListener extends DefaultTaskControlCenterListener {
    constructor(taskControlCenter: TaskControlCenter);
    executeListener(task: CoreTaskImpl): Promise<void>;
}
/**
 * 整个任务被disabled后,执行结束后触发的事件监听
 *
 * @since 2022/9/1
 */
export declare class TaskFailedListener extends DefaultTaskControlCenterListener {
    constructor(taskControlCenter: TaskControlCenter);
    executeListener(task: CoreTaskImpl): void;
}
/**
 * 整个任务被disabled后,执行结束后触发的事件监听
 *
 * @since 2022/9/1
 */
export declare class TaskDisabledListener extends DefaultTaskControlCenterListener {
    constructor(taskControlCenter: TaskControlCenter);
    executeListener(task: CoreTaskImpl): Promise<void>;
}
/**
 * 整个任务整理生效Up-to-date,不执行任务时触发的事件监听
 *
 * @since 2022/9/1
 */
export declare class TaskUpToDatedListener extends DefaultTaskControlCenterListener {
    constructor(taskControlCenter: TaskControlCenter);
    executeListener(task: CoreTaskImpl): Promise<void>;
}
export {};
