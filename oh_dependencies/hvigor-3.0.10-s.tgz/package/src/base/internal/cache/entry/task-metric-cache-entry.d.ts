import type { Metric } from '../../../metrics/metric.js';
import { CacheEntry } from './cache-entry.js';
/**
 * 包装TaskMetric对象的容器类
 *
 * @since 2022/9/1
 */
export declare class TaskMetricCacheEntry extends CacheEntry<Metric> {
    constructor(key: string, metric: Metric);
}
