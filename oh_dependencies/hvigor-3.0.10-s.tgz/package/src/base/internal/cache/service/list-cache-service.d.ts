import { CacheEntry } from '../entry/cache-entry.js';
/**
 * CacheService的一个List类型实现,可以根据容器中的具体对象,重载不同的方法实现
 *
 * @since 2022/9/6
 */
export declare abstract class ListCacheService<T> {
    protected cacheEntries: CacheEntry<T>[];
    protected constructor();
    /**
     * 初始化函数,默认只需要一个空的map,子类需要根据不同场景进行重载
     */
    initialize(): void;
    close(): void;
    get(index: number): CacheEntry<T>;
    indexOf(cacheEntry: CacheEntry<T>): number;
    remove(cacheEntry: CacheEntry<T>): void;
    size(): number;
    /**
     * Set方法需要根据具体场景进行实例化
     *
     * @param {T} entryContent
     * @return {CacheEntry<T>}
     */
    abstract add(entryContent: T): CacheEntry<T>;
}
