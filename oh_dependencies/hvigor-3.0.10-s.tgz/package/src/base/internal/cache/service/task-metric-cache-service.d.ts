import type { Metric } from '../../../metrics/metric.js';
import { TaskMetricCacheEntry } from '../entry/task-metric-cache-entry.js';
import { ListCacheService } from './list-cache-service.js';
/**
 * 提供获取TaskMetric缓存的统一服务接口
 *
 * @since 2022/9/1
 */
export declare class TaskMetricCacheService extends ListCacheService<Metric> {
    private static instance;
    private constructor();
    add(metric: Metric): TaskMetricCacheEntry;
    getMetrics(): Metric[];
    static getInstance(): TaskMetricCacheService;
}
