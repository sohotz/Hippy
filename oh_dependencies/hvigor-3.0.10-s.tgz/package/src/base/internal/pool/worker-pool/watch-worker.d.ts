/// <reference types="node" />
import { Worker, WorkerOptions } from 'worker_threads';
import { CoreTaskImpl } from '../../../external/task/core-task-impl.js';
/**
 * 用于watch任务的线程管理
 *
 * @since 2022/12/7
 */
declare class WatchWorker {
    private readonly workerMap;
    private cnt;
    getWorker(id: number): Worker | undefined;
    createWorker(task: CoreTaskImpl, filename: string, hasCustomTerminate: boolean, options?: WorkerOptions): [Worker, number];
    beforeTerminate(id: number): void;
    private terminateWorker;
    /**
     * 注册收到需要发送给worker线程的消息的事件监听
     * @param socket
     * @param {number} threadId
     * @private
     */
    private bindOnWorkerData;
    /**
     * 注册关闭worker线程的watch功能的事件监听
     * @param socket
     * @param {number} threadId
     * @private
     */
    private bindOnCloseWatch;
}
/**
 * 普通worker, 用于非daemon非socket场景，编译完成后直接terminate。
 * 目前用于预览时级联编译entry所依赖的所有hsp。
 */
declare class NormalWorker {
    private cnt;
    createWorker(task: CoreTaskImpl, filename: string, hasCustomTerminate: boolean, options?: WorkerOptions): [Worker, number];
}
export declare const watchWorker: WatchWorker;
export declare const normalWorker: NormalWorker;
export {};
