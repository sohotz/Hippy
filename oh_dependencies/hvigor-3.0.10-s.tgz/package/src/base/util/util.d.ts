/**
 * 记录打点数据：taskTime
 *
 * @param taskName
 * @param time
 */
export declare function recordTraceData(taskName: string, time: number): void;
/**
 * 判断日志是否是显示时间的Hvigor日志
 *
 * @param log 待判断的日志内容
 */
export declare function isHvigorLogWithTime(log: string): boolean;
