export declare class Json5Reader {
    private static logger;
    /**
     * 获取json5对象
     *
     * @param {string} json5path json5路径
     * @param {any} encodingStr 编码方式
     */
    static getJson5Obj(json5path: string, encodingStr?: string): any;
    /**
     * 异步API获取json5对象
     *
     * @param {string} json5path json5路径
     * @param {any} encodingStr 编码方式
     */
    static readJson5File(json5path: string, encodingStr?: string): Promise<any>;
    private static handleException;
}
