import { HvigorNode, Project } from './hvigor-node.js';
/**
 * 提供前端工程配置信息的数据类
 *
 * @since 2021/12/09
 */
declare class Hvigor {
    private _project;
    private _projectDir;
    private _projectConfigFile;
    private _extraConfig;
    private _commandEntryTasks;
    private _scriptMap;
    private _hvigorNodesEvaluatedActions;
    constructor();
    /**
     * 返回Project模型
     *
     * @returns {Project | undefined}
     */
    getProject(): Project | undefined;
    /**
     * 根据hvigorfile的文件位置返回对应node的hvigor 模型
     *
     * @param {string} buildScriptFilePath
     * @returns {HvigorNode | undefined}
     */
    getModuleByScriptPath(buildScriptFilePath: string): HvigorNode | undefined;
    /**
     * 返回在命令行中传递的额外参数
     *
     * @returns {Map<string, string>}
     */
    getExtraConfig(): Map<string, string>;
    /**
     * 保存命令行中的配置
     *
     * @param {Map<string, string>} value
     */
    setExtraConfig(value: Map<string, string>): void;
    /**
     * 判断是否是命令入口Task
     *
     * @param {string} taskName 任务名
     * @return {string[]} commandEntryTasks Task集合
     */
    isCommandEntryTask(taskName: string): boolean;
    /**
     * 保存hvigor命令行中的入口Tasks
     *
     * @param {string[]} commandEntryTasks Task集合
     */
    setCommandEntryTasks(commandEntryTasks: string[]): void;
    initRootProject(project: Project): void;
    private initSubModules;
    private checkProjectConfigFile;
    nodesEvaluated(fn: Function): void;
    getNodesEvaluatedActions(): Function[];
    reset(): void;
}
/**
 * 提供接口在module的hvigorfile.js中获取当前模块的hvigor module对象
 *
 * @param {string} buildScriptFilePath hvigorfile.js文件的路径
 * @returns {HvigorNode | undefined | Project}
 */
export declare function getHvigorNode(buildScriptFilePath?: string): HvigorNode | undefined;
/**
 * 一次构建中只存在一个hvigor的单例对象,用来保存和传递全局的信息
 */
export declare const hvigor: Hvigor;
export {};
