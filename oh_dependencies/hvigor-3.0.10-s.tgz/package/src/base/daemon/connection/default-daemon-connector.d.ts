import { Socket } from 'socket.io-client';
import { DaemonConnector } from './daemon-connector.js';
/**
 * 为client获取可用的与daemon的socket连接
 */
export declare class DefaultDaemonConnector implements DaemonConnector {
    getDaemonConnection(): Promise<Socket | undefined>;
    onConnect(...args: any[]): void;
    onClose(...args: any[]): void;
    onConnectError(...args: any[]): void;
}
