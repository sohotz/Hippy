import { DaemonInfo } from '../registry/daemon-info.js';
/**
 * 生成新daemon process的工厂类
 */
export declare class DaemonProcessFactory {
    getProjectCompatibleIdleDaemon(): Promise<DaemonInfo | undefined>;
    private killOldProcessAndCreateNew;
    private createNewIdleDaemon;
}
export declare const defaultDaemonServerFactory: DaemonProcessFactory;
