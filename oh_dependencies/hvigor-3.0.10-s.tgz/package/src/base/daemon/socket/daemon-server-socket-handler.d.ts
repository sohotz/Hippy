import { HvigorLogger } from '../../log/hvigor-log.js';
import { Message } from '../../protocol/message.js';
export declare function handleClientMsgError(log: HvigorLogger, msg: Message): void;
