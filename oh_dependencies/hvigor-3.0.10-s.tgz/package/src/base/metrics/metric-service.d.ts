import { Report } from '../report/report.js';
import { ReportListener } from '../report/report-listener.js';
import type { Metric } from './metric.js';
/**
 * 矩阵服务
 *
 * @since 2022/8/17
 */
export declare class MetricService implements ReportListener {
    private static instance;
    private taskMetricCacheService;
    private workIdRecord;
    private constructor();
    /**
     * 记录workerId
     *
     * @param workerId
     */
    addWorkerId(workerId: number): void;
    /**
     * 提交metric到缓存服务
     *
     * @param metric
     */
    submit(metric: Metric): void;
    /**
     * 供报告服务查询报告
     */
    queryReport(): Report<Metric[]>;
    /**
     * 清除缓存
     */
    clear(): void;
    static getInstance(): MetricService;
}
