import { Report } from '../report/report.js';
import { ReportListener } from '../report/report-listener.js';
/**
 * workerId记录
 *
 * @since 2022/8/27
 */
export declare class WorkerIdRecord implements ReportListener {
    private static instance;
    private workerIdList;
    private constructor();
    /**
     * 记录workerId
     *
     * @param workerId
     */
    addWorkerId(workerId: number): void;
    queryReport(): Report<number[]>;
    clear(): void;
    static getInstance(): WorkerIdRecord;
}
