/**
 * 矩阵当前状态
 */
export declare enum MetricStatus {
    READY = "ready",
    STARTED = "started",
    BEGINNING = "beginning",
    CLOSED = "closed"
}
/**
 * 矩阵类型
 */
export declare enum MetricType {
    BUILD_LINE = "build_line",
    DEFAULT = "default"
}
/**
 * 矩阵实体
 *
 * @since 2022/8/17
 */
export declare class Metric {
    private readonly name;
    private type;
    private readonly taskName;
    private readonly taskPath;
    private workerId;
    private startTime;
    private endTime;
    private status;
    private children;
    constructor(name: string, taskName: string, taskPath: string, workerId: number);
    /**
     * 设置矩阵类型
     *
     * @param type
     */
    withType(type: MetricType): Metric;
    /**
     * 设置线程ID或进程ID
     *
     * @param workerId
     */
    setWorkerId(workerId: number): void;
    /**
     * 设置矩阵状态
     *
     * @param status
     */
    setStatus(status: MetricStatus): void;
    /**
     * 显示地启动矩阵，记录开始时间
     *
     * @param startTime
     */
    start(startTime?: number): void;
    /**
     * 关闭矩阵，记录结束时间
     * 一个矩阵只能被关闭一次
     *
     * @param endTime
     */
    close(endTime?: number): void;
    /**
     * 创建子矩阵
     *
     * @param name
     */
    createSubMetric(name?: string): Metric;
    addChild(metric: Metric): void;
    /**
     * 计算耗费时间长度，单位ms级别
     */
    calcTimeDiff(): number;
    getName(): string;
    getType(): MetricType;
    getTaskName(): string;
    getTaskPath(): string;
    getWorkerId(): number;
    getStartTime(): number;
    getEndTime(): number;
    getStatus(): MetricStatus;
    getChildren(): Metric[];
}
