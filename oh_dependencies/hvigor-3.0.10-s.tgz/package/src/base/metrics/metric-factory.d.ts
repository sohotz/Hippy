import { Metric } from './metric.js';
/**
 * 矩阵工厂
 *
 * @since 2022/8/17
 */
export declare class MetricFactory {
    private static instance;
    private constructor();
    newMetric(name: string, taskName: string, taskPath: string, workerId?: number): Metric;
    static getInstance(): MetricFactory;
}
