import { HvigorConfigJson, HvigorInitProjectWorkSpaceParams } from './type.js';
/**
 * 这里检查和安装依赖主要是为了兼容之前老工程的 hvigor-wrapper.js ,因为老工程是2段式安装的。
 * 先在hvigor-wrapper.js中安装 hvigor,再在 hvigor.js 中安装其它所有依赖。
 * 新的 hvigor-wrapper.js 我们都改成了1段式安装，在 hvigor-wrapper.js安装 hvigor 和所有依赖。
 * 对于新的 hvigor-wrapper.js 这里其实时重复判断的。
 */
export declare function initProjectWorkSpace(projectHome: string, params: HvigorInitProjectWorkSpaceParams): void;
/**
 * 判断工程中配置的构建相关依赖是否已安装对应版本
 *
 * @returns {boolean}
 */
export declare function isAllDependenciesInstalled(): boolean;
export declare function executeInstallDependencies(params: HvigorInitProjectWorkSpaceParams): void;
export declare function readProjectHvigorConfig(): HvigorConfigJson;
