export type Dependency = Record<string, string>;
export type PackageJson = {
    dependencies: Dependency;
};
export type HvigorConfigJson = {
    hvigorVersion: string;
    dependencies: Dependency;
};
