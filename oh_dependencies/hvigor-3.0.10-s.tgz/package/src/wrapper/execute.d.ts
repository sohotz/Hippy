/**
 * 启动hvigor构建
 */
export declare function executeBuild(hvigorProjectDependenciesHome: string): void;
