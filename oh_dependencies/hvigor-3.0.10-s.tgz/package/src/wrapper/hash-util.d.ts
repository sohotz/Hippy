/**
 * 计算对应value的hash值
 *
 * @param {string} value
 * @param {string} algorithm
 * @returns {string}
 */
export declare function hash(value: string, algorithm?: string): string;
