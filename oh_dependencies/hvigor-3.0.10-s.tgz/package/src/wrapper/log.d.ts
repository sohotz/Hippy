/**
 * 打印error信息并退出执行,直接throw error会打出多余堆栈信息
 *
 * @param error
 */
export declare function logErrorAndExit(error: unknown): void;
/**
 * 打印log日志(wrapper命令行工具专用)
 * 一般场景不建议使用console打印日志，
 *
 * @param log
 */
export declare function logInfoPrintConsole(log: string): void;
