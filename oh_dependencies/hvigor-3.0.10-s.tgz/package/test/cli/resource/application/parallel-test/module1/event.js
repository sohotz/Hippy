/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2022-2022. All rights reserved.
 */


module.exports = async function (options) {
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({type: 'async event'});

      console.log(`doing ${options.name}...`);
    }, 3000);
  });
}; 