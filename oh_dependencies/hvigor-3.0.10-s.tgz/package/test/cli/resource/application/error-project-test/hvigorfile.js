// Script for compiling build behavior. It is built in the build plug-in and cannot be modified currently.
let project = require('@ohos/hvigor')(__filename);

// 工程的clean依赖模块entry的clean
project.task(() => {
  console.log('This is a clean task');
}, 'clean');

