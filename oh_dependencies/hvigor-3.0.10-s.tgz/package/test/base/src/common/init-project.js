"use strict";
/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2022-2022. All rights reserved.
 */
Object.defineProperty(exports, "__esModule", { value: true });
// export function mockProjectFromResourcesPath(projectName: string): Project {
//   const projectPath = path.resolve('test/resource/application/', projectName);
//
//   return hvigor.initRootProject(projectPath);
// }
//# sourceMappingURL=init-project.js.map