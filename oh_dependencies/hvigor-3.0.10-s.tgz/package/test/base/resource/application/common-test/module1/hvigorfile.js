// Script for compiling build behavior. It is built in the build plug-in and cannot be modified currently.
let project = require('@ohos/hvigor')(__filename);

project.task(() => {
  console.log('This is a clean task');
}, {
  name:'clean',
  description:'This is module1 clean task'
});

project.task(() => {
  console.log('This is a default task');
}, {
  name: 'task1',
  isEnabled: false
});

// 依赖模块自身的任务
project.task(() => {
  console.log('This is a default task');
}, 'task2').dependsOn('task1');

// 依赖工程的clean任务
project.task(() => {
  console.log('This is a test task');
}, 'test').dependsOn('clean', ':');


